import test

ai=test.getwinner()
test.training(ai,1)

	
	
